# ds

#### 介绍
纯静态导航网站、集合从事互联网工作的优秀资源网站

#### 软件架构
主要用到的技术html\js\cs


#### 安装教程
任选一
1.本地路径打开
2.tomcat部署
3.nignx部署
4.云服务器上
5.部署到gitee上

#### 网站效果图
![输入图片说明](https://images.gitee.com/uploads/images/2020/0717/155102_fe3b92ed_1981977.jpeg "1594972033(1).jpg")

#### 网站预览网址
地址：[点击预览网站](https://taisan.gitee.io/ds/)

#### 技术交流&问题反馈
      联系QQ:1334512682 微信号：vxhqqh

